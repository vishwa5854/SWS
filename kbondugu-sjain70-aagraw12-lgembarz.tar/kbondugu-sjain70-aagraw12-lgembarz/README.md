### Group Assignment 

## Team
<ol>
<li>Vishwanath</li>
<li>Lucas</li>
<li>Siddharth</li>
<li>Anmol</li>

<hr>
Asana.com link : <a>https://app.asana.com/share/vishw/cs631/1203202255113786/ac1cd1613952692d3cae622be0ecd424
</a>



## Our Plan
<ol>
<li>Together : Create boilerplate code for the server</li>
<li>Then devide each segment to individual members</li>
<li>If any memeber is facing difficulty then all come together to collaborate with him</li>
</ol>