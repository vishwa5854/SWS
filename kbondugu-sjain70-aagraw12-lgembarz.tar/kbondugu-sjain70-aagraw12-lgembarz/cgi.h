#ifndef CGI_H
#define CGI_H
int     execute_file(const char *string, char *outbuf, int outlen, char *errbuf, int errlen, char *fileName);
#endif
