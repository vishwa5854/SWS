#ifndef GETUSERDIR
#define GETUSERDIR_H

char** getuserdir(char* username);

#endif /* GETUSERDIR_H */
