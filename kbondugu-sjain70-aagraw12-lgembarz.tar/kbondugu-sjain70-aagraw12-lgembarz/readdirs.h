#ifndef READDIRS
#define READDIRS_H

char** readdirs(char* dirname, int flag);

#endif /* READDIRS_H */
