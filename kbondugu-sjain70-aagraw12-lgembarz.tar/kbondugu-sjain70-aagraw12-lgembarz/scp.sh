scp -P 2222 -r /home/z/Desktop/CS631/CS631-Group-Assignment-SWS z@127.0.0.1:/home/z/CS631-Group-Assignment-SWS
