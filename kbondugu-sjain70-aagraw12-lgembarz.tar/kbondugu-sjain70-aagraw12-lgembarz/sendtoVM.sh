#!/bin/sh
scp -i ..\..\..\..\keys\id_rsa -r cgi.c cgi.h sid@192.168.1.177:/home/sid/sws